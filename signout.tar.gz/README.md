# signout
## Boat signout app

### Hey Luke - feel free to tinker and bring it out of 1996

### Intention is to get this on a raspberry pi with a GPRS connection (running locally, storing remotely) at the club so that a "forgotten signout/hazards/person tracker" can be online and connected to the same database

### Cheers!

my TODOS:
- set up mysql on aws - figure out how to migrate this in one piece and how this can be automated
	- set up on aws rdb - didn't get automated but idc
- add to an AWS ec2 instance
- hazards - collection and communication of hazards on the river
- Password storage, reset requests (?)
- Some responsiveness to say that the boat has been booked succesfully
- login management - username taken etc
- all of the messaging layer - pinging people when they forget to sign back in - creating some kind of notification if someone is vulnerable (weather connection?)
- hazards API
- boats on the water API

Connect to the booking system to present that onscreen...?

Talk to Andy R for access to this
